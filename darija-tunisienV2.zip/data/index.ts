/**
 * /data/index.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Point d'entrée unique de la couche de données.
 *
 * Importer depuis "@/data" plutôt que depuis les fichiers individuels
 * pour faciliter les refactorisations futures.
 * ─────────────────────────────────────────────────────────────────────────────
 */

export { verbs, verbsById, getVerbById, getVerbsByLevel } from './verbs';

export {
  vocabulary,
  vocabularyById,
  getWordById,
  getWordsByCategory,
  getWordsByFrequency,
  getDiasporaWords,
} from './vocabulary';

export {
  grammarRules,
  grammarRulesById,
  getGrammarRuleById,
  getRulesByCategory,
  getRulesByLevel,
} from './grammar';

export {
  dialogues,
  dialoguesById,
  getDialogueById,
  getDialoguesByContext,
  getDialoguesByLevel,
} from './dialogues';

export {
  modules,
  lessons,
  modulesById,
  lessonsById,
  getModuleById,
  getLessonById,
  getLessonsByModule,
  getNextUnlockedLesson,
} from './lessons';

export {
  PRONOUNS,
  PRONOUN_ORDER,
  getPronoun,
} from './pronouns';

export {
  ALL_PATTERNS,
  PAST_PATTERN_CCC,
  PRESENT_PATTERN_CCC,
  applyPattern,
} from './conjugationRules';
