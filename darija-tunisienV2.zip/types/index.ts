/**
 * Types du domaine métier — Darija Tunisien
 */

// ─── Niveaux & progression ────────────────────────────────────────────────────

export type Level = 'debutant' | 'elementaire' | 'intermediaire' | 'avance';

export type SkillType =
  | 'vocabulaire'
  | 'grammaire'
  | 'conjugaison'
  | 'comprehension'
  | 'expression';

// ─── Mots & vocabulaire ───────────────────────────────────────────────────────

export type WordCategory =
  | 'salutations'
  | 'famille'
  | 'nourriture'
  | 'chiffres'
  | 'couleurs'
  | 'corps'
  | 'maison'
  | 'transport'
  | 'travail'
  | 'emotions'
  | 'temps'
  | 'vêtements'
  | 'shopping'
  | 'loisirs'
  | 'nature'
  | 'autres';

export interface Word {
  id: string;
  darija: string;               // En graphie arabe : مرحبا
  darijaLatin: string;          // Translittération : Merhba
  phonetic: string;             // Phonétique IPA approximative : [meɾħba]
  french: string;               // Traduction française
  category: WordCategory;
  level: Level;
  exampleSentenceDarija?: string;
  exampleSentenceFrench?: string;
  audioFileName?: string;       // Prévu pour V2
  tags: string[];
}

// ─── Verbes ───────────────────────────────────────────────────────────────────

export type Tense = 'present' | 'passe' | 'futur' | 'imperatif';
export type Person = '1s' | '2s' | '3sm' | '3sf' | '1p' | '2p' | '3p';

export interface VerbConjugation {
  person: Person;
  form: string;           // Darija en arabe
  formLatin: string;      // Translittération
  phonetic: string;
  // OPTIONNEL — découpage morphologique pour l'affichage visuel coloré.
  // Absent par défaut dans les données actuelles : MorphologyBlock prévoit
  // un fallback lisible tant que ce champ n'est pas renseigné.
  // Concaténer les segments doit reformer formLatin.
  morphology?: Array<{
    text: string;
    role: 'prefix' | 'root' | 'suffix' | 'particle' | 'exception';
  }>;
}

export interface Verb {
  id: string;
  infinitiveFrench: string;   // ex: "manger"
  rootDarija: string;         // Racine en arabe
  rootLatin: string;          // Racine translittérée
  conjugations: Partial<Record<Tense, VerbConjugation[]>>;
  level: Level;
  tags: string[];
  isIrregular: boolean;
  notes?: string;
}

// ─── Leçons ───────────────────────────────────────────────────────────────────

export type LessonType =
  | 'vocabulaire'
  | 'dialogue'
  | 'grammaire'
  | 'culture'
  | 'conjugaison';

export interface Lesson {
  id: string;
  title: string;
  titleDarija?: string;
  description: string;
  type: LessonType;
  level: Level;
  estimatedMinutes: number;
  wordIds: string[];          // Références vers Word[]
  verbIds?: string[];
  grammarPointIds?: string[];
  order: number;              // Ordre dans le module
  moduleId: string;
  isUnlocked: boolean;
  culturalNote?: string;
}

export interface Module {
  id: string;
  title: string;
  description: string;
  level: Level;
  lessonIds: string[];
  coverEmoji: string;
  order: number;
}

// ─── Grammaire ────────────────────────────────────────────────────────────────
// Note : le concept de "point de grammaire" est porté par l'interface
// GrammarRule (plus riche, définie plus bas). Le champ Lesson.grammarPointIds
// référence des IDs de GrammarRule (résolus via getGrammarRuleById).

// ─── Quiz ─────────────────────────────────────────────────────────────────────

export type QuizQuestionType =
  | 'choix_multiple'
  | 'vrai_faux'
  | 'traduction_fr_darija'
  | 'traduction_darija_fr'
  | 'completion'
  | 'association';

export interface QuizQuestion {
  id: string;
  type: QuizQuestionType;
  question: string;
  options?: string[];
  correctAnswer: string | string[];
  explanation?: string;
  wordId?: string;
  verbId?: string;
  points: number;
}

export interface Quiz {
  id: string;
  title: string;
  lessonId?: string;
  moduleId?: string;
  questions: QuizQuestion[];
  passingScore: number;       // % minimum pour valider
  timeLimit?: number;         // En secondes, optionnel
}

// ─── Progression utilisateur ──────────────────────────────────────────────────

export interface WordProgress {
  wordId: string;
  seenCount: number;
  correctCount: number;
  incorrectCount: number;
  lastSeenAt: string;         // ISO date string
  masteryLevel: 0 | 1 | 2 | 3 | 4 | 5;  // 0=jamais vu, 5=maîtrisé
  nextReviewAt: string;       // ISO date string (SRS)
}

export interface LessonProgress {
  lessonId: string;
  completedAt?: string;
  score?: number;
  attempts: number;
}

export interface UserProfile {
  id: string;
  createdAt: string;
  displayName?: string;
  motivations: string[];      // Pourquoi apprendre le tunisien
  dailyGoalMinutes: number;
  notificationsEnabled: boolean;
}

export interface UserStats {
  totalXP: number;
  currentStreak: number;      // Jours consécutifs
  longestStreak: number;
  lessonsCompleted: number;
  wordsLearned: number;
  wordsReviewed: number;
  quizzesTaken: number;
  totalTimeMinutes: number;
  lastActivityAt: string;
}

// ─── Révision (SRS) ───────────────────────────────────────────────────────────

export interface ReviewSession {
  id: string;
  startedAt: string;
  completedAt?: string;
  wordIds: string[];
  results: Array<{
    wordId: string;
    correct: boolean;
    responseTimeMs: number;
  }>;
}

// ─── Navigation ───────────────────────────────────────────────────────────────

export type TabName =
  | 'accueil'
  | 'lecon'
  | 'revisions'
  | 'verbes'
  | 'vocabulaire'
  | 'quiz'
  | 'grammaire'
  | 'profil';

// ─── VocabularyItem ───────────────────────────────────────────────────────────
// Extension enrichie de Word, avec champs pédagogiques supplémentaires.
// Utilisé dans les écrans Vocabulaire et les fiches de révision.

export type VocabularyDomain =
  | 'quotidien'     // Usage de tous les jours
  | 'formel'        // Contextes polis / adultes
  | 'familier'      // Langage entre proches
  | 'diaspora';     // Expressions spécifiques à la diaspora

export interface VocabularyItem extends Word {
  domain: VocabularyDomain;
  // Faux amis ou pièges fréquents pour les francophones
  falseFreindNote?: string;
  // Niveau de fréquence d'usage (1 = très courant, 5 = rare)
  frequencyRank: 1 | 2 | 3 | 4 | 5;
  // Variantes régionales (Tunis vs Sfax vs Sousse…)
  regionalVariants?: Array<{
    region: string;
    form: string;
    formLatin: string;
  }>;
  // Mot lié sémantiquement (antonyme, synonyme…)
  relatedWordIds?: string[];
}

// ─── GrammarRule ─────────────────────────────────────────────────────────────
// Règle grammaticale structurée : l'unique modèle pour les points de grammaire.
// Inclut un pattern formel et des contre-exemples.

export type GrammarCategory =
  | 'article'
  | 'negation'
  | 'possession'
  | 'pluriel'
  | 'genre'
  | 'temps'
  | 'interrogation'
  | 'comparaison'
  | 'preposition'
  | 'autre';

export interface GrammarExample {
  darija: string;       // Ex : ما ماكلتش
  darijaLatin: string;  // Ex : Ma maklitsh
  phonetic: string;     // Ex : [ma maklɪtʃ]
  french: string;       // Ex : Je n'ai pas mangé
  isCounterExample?: boolean; // true = exemple de ce qu'il ne faut PAS dire
}

export interface GrammarRule {
  id: string;
  title: string;
  category: GrammarCategory;
  level: Level;
  // Explication en français, claire et concise
  explanation: string;
  // Pattern formel, ex : "Ma + verbe + sh"
  pattern?: string;
  examples: GrammarExample[];
  // Exceptions notables à la règle
  exceptions?: string[];
  // IDs des leçons qui enseignent cette règle
  lessonIds: string[];
  // IDs des règles préalables à maîtriser
  prerequisiteRuleIds?: string[];
}

// ─── Dialogue ─────────────────────────────────────────────────────────────────
// Dialogue authentique entre deux interlocuteurs.
// Conçu pour simuler des échanges réels que la diaspora peut rencontrer.

export type DialogueSpeaker = 'A' | 'B';

export interface DialogueLine {
  speaker: DialogueSpeaker;
  darija: string;
  darijaLatin: string;
  phonetic?: string;
  french: string;
  // Mots clés de cette ligne pointant vers le vocabulaire
  wordIds?: string[];
  // Note culturelle ou pragmatique sur cette ligne
  note?: string;
}

export type DialogueContext =
  | 'famille'
  | 'marche'        // Marché / shopping
  | 'restaurant'
  | 'telephone'
  | 'rue'
  | 'maison'
  | 'travail'
  | 'celebrations'; // Mariages, Aid, etc.

export interface Dialogue {
  id: string;
  title: string;
  context: DialogueContext;
  level: Level;
  // Description de la situation en français
  situationFrench: string;
  // Description brève en darija (pour les niveaux avancés)
  situationDarija?: string;
  lines: DialogueLine[];
  // Vocabulaire clé à retenir après le dialogue
  keyWordIds: string[];
  // Règles de grammaire illustrées par ce dialogue
  grammarRuleIds?: string[];
  // Note culturelle associée
  culturalNote?: string;
  estimatedMinutes: number;
}

// ─── ReviewItem ───────────────────────────────────────────────────────────────
// Élément de révision dans le système SRS (Spaced Repetition System).
// Peut représenter un mot, un verbe, une règle ou une ligne de dialogue.

export type ReviewItemType =
  | 'vocabulaire'
  | 'verbe'
  | 'grammaire'
  | 'dialogue_line';

export type ReviewCardSide = 'french_to_darija' | 'darija_to_french' | 'audio_to_french';

export interface ReviewItem {
  id: string;                     // Ex : "review_word_salut_001"
  itemType: ReviewItemType;
  // ID de l'entité source (wordId, verbId, grammarRuleId…)
  sourceId: string;
  // Côté de la carte à tester
  cardSide: ReviewCardSide;
  // --- Données SRS ---
  // Intervalle actuel en jours avant la prochaine révision
  intervalDays: number;
  // Facteur de facilité (2.5 par défaut, algo SM-2)
  easeFactor: number;
  // Nombre de fois que la carte a été bien répondue d'affilée
  consecutiveCorrect: number;
  // Historique compact : 'c' = correct, 'i' = incorrect
  history: Array<'c' | 'i'>;
  lastReviewedAt: string;         // ISO date string
  nextReviewAt: string;           // ISO date string
  // Niveau de maîtrise calculé 0–5
  masteryLevel: 0 | 1 | 2 | 3 | 4 | 5;
}
