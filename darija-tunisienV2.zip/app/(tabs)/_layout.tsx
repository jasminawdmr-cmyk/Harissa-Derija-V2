import { Tabs } from 'expo-router';
import { Platform, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Theme } from '@/lib/Theme';
import { TextStyles } from '@/lib/Typography';

type IoniconName = React.ComponentProps<typeof Ionicons>['name'];

interface TabConfig {
  name: string;
  title: string;
  icon: IoniconName;
  iconFocused: IoniconName;
}

const TABS: TabConfig[] = [
  { name: 'index',       title: 'Accueil',     icon: 'home-outline',        iconFocused: 'home' },
  { name: 'lecon',       title: 'Leçon',       icon: 'book-outline',        iconFocused: 'book' },
  { name: 'revisions',   title: 'Révisions',   icon: 'school-outline',      iconFocused: 'school' },
  { name: 'verbes',      title: 'Verbes',      icon: 'chatbubble-outline',  iconFocused: 'chatbubble' },
  { name: 'vocabulaire', title: 'Vocab',       icon: 'library-outline',     iconFocused: 'library' },
  { name: 'quiz',        title: 'Quiz',        icon: 'trophy-outline',      iconFocused: 'trophy' },
  { name: 'grammaire',   title: 'Grammaire',   icon: 'document-text-outline', iconFocused: 'document-text' },
  { name: 'profil',      title: 'Profil',      icon: 'person-outline',      iconFocused: 'person' },
];

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: Theme.colors.tabActive,
        tabBarInactiveTintColor: Theme.colors.tabInactive,
        tabBarStyle: styles.tabBar,
        tabBarLabelStyle: styles.tabLabel,
        tabBarItemStyle: styles.tabItem,
      }}
    >
      {TABS.map(({ name, title, icon, iconFocused }) => (
        <Tabs.Screen
          key={name}
          name={name}
          options={{
            title,
            tabBarIcon: ({ focused, color, size }: { focused: boolean; color: string; size: number }) => (
              <Ionicons
                name={focused ? iconFocused : icon}
                size={size ?? 22}
                color={color}
              />
            ),
          }}
        />
      ))}
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: Theme.colors.tabBackground,
    borderTopColor: Theme.colors.borderLight,
    borderTopWidth: 1,
    height: Platform.OS === 'ios' ? 85 : 68,
    paddingTop: 6,
    paddingBottom: Platform.OS === 'ios' ? 24 : 10,
    ...Theme.shadows.sm,
  },
  tabLabel: {
    ...TextStyles.tabLabel,
    marginTop: 2,
  },
  tabItem: {
    paddingTop: 2,
  },
});
