import React from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { ScreenContainer } from '@/components/layout/ScreenContainer';
import { ScreenHeader } from '@/components/layout/ScreenHeader';
import { Flashcard } from '@/components/common/Flashcard';
import { ProgressBar } from '@/components/common/ProgressBar';
import { EmptyState } from '@/components/common/EmptyState';
import { Button } from '@/components/common/Button';
import { StatTile } from '@/components/common/StatTile';
import { Theme } from '@/lib/Theme';
import { TextStyles } from '@/lib/Typography';
import { useReviewSession } from '@/hooks/useReviewSession';

/**
 * Écran Révisions — héberge la session de flashcards.
 * Délègue toute la logique au hook useReviewSession (moteur + persistance).
 */
export default function RevisionsScreen() {
  const {
    phase,
    currentCard,
    currentIndex,
    totalCards,
    answer,
    stats,
    restart,
  } = useReviewSession();

  return (
    <ScreenContainer scrollable={phase !== 'active'}>
      <ScreenHeader
        title="Révisions"
        subtitle="Réactivez ce que vous avez appris"
        accentColor={Theme.rawColors.azure[400]}
      />

      {/* Chargement */}
      {phase === 'loading' && (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color={Theme.colors.primary} />
          <Text style={styles.loadingText}>Préparation de votre session…</Text>
        </View>
      )}

      {/* Rien à réviser */}
      {phase === 'empty' && (
        <EmptyState
          emoji="🧠"
          title="Tout est à jour !"
          description="Vous n'avez aucune carte à réviser pour le moment. Le système de répétition espacée planifiera automatiquement vos prochaines révisions."
        />
      )}

      {/* Session active */}
      {phase === 'active' && currentCard && (
        <View style={styles.sessionContainer}>
          {/* Progression de la session */}
          <View style={styles.progressHeader}>
            <Text style={styles.progressText}>
              {currentIndex + 1} / {totalCards}
            </Text>
            <ProgressBar
              progress={(currentIndex + 1) / totalCards}
              height={6}
              style={styles.progressBar}
            />
          </View>

          {/* Carte courante */}
          <Flashcard card={currentCard} onAnswer={answer} />
        </View>
      )}

      {/* Session terminée */}
      {phase === 'finished' && stats && (
        <View style={styles.resultsContainer}>
          <Text style={styles.resultsEmoji}>🎉</Text>
          <Text style={styles.resultsTitle}>Session terminée !</Text>
          <Text style={styles.resultsSubtitle}>
            {stats.totalCards} cartes révisées en{' '}
            {Math.max(1, Math.round(stats.durationSeconds / 60))} min
          </Text>

          {/* Statistiques de la session */}
          <View style={styles.statsRow}>
            <StatTile
              icon="✓"
              value={String(stats.correctCount)}
              label="su"
              accentColor={Theme.colors.secondary}
            />
            <StatTile
              icon="~"
              value={String(stats.hesitantCount)}
              label="hésité"
              accentColor={Theme.rawColors.warning}
            />
            <StatTile
              icon="✗"
              value={String(stats.incorrectCount)}
              label="à revoir"
              accentColor={Theme.rawColors.error}
            />
          </View>

          <View style={styles.xpBanner}>
            <Text style={styles.xpText}>+{stats.xpEarned} XP</Text>
            {stats.newlyMasteredIds.length > 0 && (
              <Text style={styles.masteredText}>
                {stats.newlyMasteredIds.length} carte
                {stats.newlyMasteredIds.length > 1 ? 's' : ''} maîtrisée
                {stats.newlyMasteredIds.length > 1 ? 's' : ''} ✨
              </Text>
            )}
          </View>

          <Button
            label="Nouvelle session"
            onPress={restart}
            fullWidth
            style={styles.restartButton}
          />
        </View>
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  centered: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Theme.spacing[20],
    gap: Theme.spacing[4],
  },
  loadingText: {
    ...TextStyles.body,
    color: Theme.colors.textSecondary,
  },
  sessionContainer: {
    gap: Theme.spacing[5],
  },
  progressHeader: {
    gap: Theme.spacing[2],
  },
  progressText: {
    ...TextStyles.caption,
    color: Theme.colors.textMuted,
    textAlign: 'center',
  },
  progressBar: {
    width: '100%',
  },
  resultsContainer: {
    alignItems: 'center',
    paddingTop: Theme.spacing[8],
    gap: Theme.spacing[3],
  },
  resultsEmoji: {
    fontSize: 56,
  },
  resultsTitle: {
    ...TextStyles.screenTitle,
    color: Theme.colors.textPrimary,
  },
  resultsSubtitle: {
    ...TextStyles.body,
    color: Theme.colors.textSecondary,
    textAlign: 'center',
    marginBottom: Theme.spacing[3],
  },
  statsRow: {
    flexDirection: 'row',
    gap: Theme.spacing[3],
    alignSelf: 'stretch',
  },
  xpBanner: {
    alignItems: 'center',
    backgroundColor: Theme.rawColors.olive[50],
    borderRadius: Theme.radii.lg,
    paddingVertical: Theme.spacing[4],
    paddingHorizontal: Theme.spacing[6],
    marginTop: Theme.spacing[3],
    alignSelf: 'stretch',
    gap: Theme.spacing[1],
  },
  xpText: {
    ...TextStyles.sectionTitle,
    color: Theme.rawColors.olive[600],
  },
  masteredText: {
    ...TextStyles.bodySmall,
    color: Theme.rawColors.olive[500],
  },
  restartButton: {
    marginTop: Theme.spacing[4],
    alignSelf: 'stretch',
  },
});
